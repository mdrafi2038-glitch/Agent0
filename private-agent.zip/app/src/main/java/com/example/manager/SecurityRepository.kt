package com.example.manager

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AdminCommand
import com.example.model.AgentSettings
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.DeviceTelemetry
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.model.IntruderSnapshot
import com.example.model.ManagedDevice
import com.example.model.SecurityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object SecurityRepository {

    private val _telemetry = MutableStateFlow(DeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private val _events = MutableStateFlow<List<SecurityEvent>>(emptyList())
    val events: StateFlow<List<SecurityEvent>> = _events.asStateFlow()

    private val _snapshots = MutableStateFlow<List<IntruderSnapshot>>(emptyList())
    val snapshots: StateFlow<List<IntruderSnapshot>> = _snapshots.asStateFlow()

    private val _settings = MutableStateFlow(AgentSettings())
    val settings: StateFlow<AgentSettings> = _settings.asStateFlow()

    private val _commands = MutableStateFlow<List<AdminCommand>>(emptyList())
    val commands: StateFlow<List<AdminCommand>> = _commands.asStateFlow()

    private val _managedDevices = MutableStateFlow<List<ManagedDevice>>(emptyList())
    val managedDevices: StateFlow<List<ManagedDevice>> = _managedDevices.asStateFlow()

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var prefs: SharedPreferences? = null

    fun initialize(context: Context) {
        prefs = context.getSharedPreferences("private_agent_prefs", Context.MODE_PRIVATE)
        loadSettingsFromPrefs()
        seedInitialData()
    }

    private fun loadSettingsFromPrefs() {
        val p = prefs ?: return
        val armed = p.getBoolean("anti_theft_armed", true)
        val unplug = p.getBoolean("unplug_alarm_enabled", true)
        val motion = p.getBoolean("motion_alarm_enabled", false)
        val selfie = p.getBoolean("intruder_selfie_enabled", true)
        val maxAttempts = p.getInt("max_failed_attempts", 3)
        val lockMsg = p.getString(
            "custom_lock_message",
            "This device is protected by Private Agent. Please return to the owner."
        ) ?: "Protected by Private Agent."
        val phone = p.getString("owner_contact_phone", "+1 800-555-0199") ?: "+1 800-555-0199"
        val pin = p.getString("emergency_pin", "1234") ?: "1234"

        _settings.value = AgentSettings(
            antiTheftArmed = armed,
            unplugAlarmEnabled = unplug,
            motionAlarmEnabled = motion,
            intruderSelfieEnabled = selfie,
            maxFailedAttempts = maxAttempts,
            customLockMessage = lockMsg,
            ownerContactPhone = phone,
            emergencyPin = pin
        )
    }

    fun updateSettings(newSettings: AgentSettings) {
        _settings.value = newSettings
        prefs?.edit()?.apply {
            putBoolean("anti_theft_armed", newSettings.antiTheftArmed)
            putBoolean("unplug_alarm_enabled", newSettings.unplugAlarmEnabled)
            putBoolean("motion_alarm_enabled", newSettings.motionAlarmEnabled)
            putBoolean("intruder_selfie_enabled", newSettings.intruderSelfieEnabled)
            putInt("max_failed_attempts", newSettings.maxFailedAttempts)
            putString("custom_lock_message", newSettings.customLockMessage)
            putString("owner_contact_phone", newSettings.ownerContactPhone)
            putString("emergency_pin", newSettings.emergencyPin)
            putBoolean("camera_disabled_policy", newSettings.cameraDisabledByPolicy)
            apply()
        }
    }

    fun logEvent(
        title: String,
        description: String,
        severity: EventSeverity,
        type: EventType
    ) {
        val event = SecurityEvent(
            title = title,
            description = description,
            severity = severity,
            type = type
        )
        _events.update { current ->
            listOf(event) + current.take(99)
        }
    }

    fun addSnapshot(snapshot: IntruderSnapshot) {
        _snapshots.update { current ->
            listOf(snapshot) + current.take(49)
        }
    }

    fun updateTelemetry(telemetry: DeviceTelemetry) {
        _telemetry.value = telemetry
    }

    fun setSirenActive(active: Boolean) {
        _isSirenActive.value = active
    }

    fun setLocked(locked: Boolean) {
        _isLocked.value = locked
    }

    fun addCommand(command: AdminCommand) {
        _commands.update { current ->
            listOf(command) + current.take(49)
        }
    }

    fun updateCommandStatus(commandId: String, status: CommandStatus, resultSummary: String) {
        _commands.update { current ->
            current.map { cmd ->
                if (cmd.id == commandId) {
                    cmd.copy(status = status, resultSummary = resultSummary)
                } else {
                    cmd
                }
            }
        }
    }

    private fun seedInitialData() {
        if (_events.value.isEmpty()) {
            val now = System.currentTimeMillis()
            _events.value = listOf(
                SecurityEvent(
                    timestamp = now - 3600000 * 2,
                    title = "Agent Service Initialized",
                    description = "Private Agent security subsystem booted and actively monitoring hardware telemetry.",
                    severity = EventSeverity.INFO,
                    type = EventType.ADMIN_STATUS
                ),
                SecurityEvent(
                    timestamp = now - 3600000,
                    title = "Integrity Check Passed",
                    description = "Full system audit executed: Encryption verified, no unauthorized root binary found.",
                    severity = EventSeverity.INFO,
                    type = EventType.ADMIN_STATUS
                ),
                SecurityEvent(
                    timestamp = now - 1800000,
                    title = "Anti-Theft Armed",
                    description = "Intruder detection, unplug alert, and motion shield armed in background.",
                    severity = EventSeverity.INFO,
                    type = EventType.POLICY_CHANGE
                )
            )
        }

        if (_managedDevices.value.isEmpty()) {
            val now = System.currentTimeMillis()
            _managedDevices.value = listOf(
                ManagedDevice(
                    deviceId = "agent_primary",
                    deviceName = "Primary Secured Unit (This Device)",
                    model = android.os.Build.MODEL ?: "Android Device",
                    osVersion = "Android ${android.os.Build.VERSION.RELEASE}",
                    batteryPercent = 94,
                    isOnline = true,
                    isProtected = true,
                    lastSeenTimestamp = now,
                    latitude = 37.7749,
                    longitude = -122.4194
                ),
                ManagedDevice(
                    deviceId = "agent_tablet_02",
                    deviceName = "Executive Field Tablet",
                    model = "Galaxy Tab Active",
                    osVersion = "Android 14",
                    batteryPercent = 78,
                    isOnline = true,
                    isProtected = true,
                    lastSeenTimestamp = now - 120000,
                    latitude = 37.7833,
                    longitude = -122.4167
                ),
                ManagedDevice(
                    deviceId = "agent_remote_03",
                    deviceName = "Warehouse Scanner Alpha",
                    model = "Pixel 8 Pro",
                    osVersion = "Android 15",
                    batteryPercent = 42,
                    isOnline = false,
                    isProtected = true,
                    lastSeenTimestamp = now - 3600000 * 5,
                    latitude = 37.7915,
                    longitude = -122.4056
                )
            )
        }
    }
}
