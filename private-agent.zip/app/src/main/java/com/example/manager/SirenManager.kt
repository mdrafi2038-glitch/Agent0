package com.example.manager

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object SirenManager {

    private var sirenJob: Job? = null
    private var vibrator: Vibrator? = null

    fun startSiren(context: Context) {
        if (SecurityRepository.isSirenActive.value) return

        SecurityRepository.setSirenActive(true)

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // Ensure alarm stream volume is audible
        audioManager?.setStreamVolume(
            AudioManager.STREAM_ALARM,
            audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM),
            0
        )

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        sirenJob = CoroutineScope(Dispatchers.Default).launch {
            var toneGenerator: ToneGenerator? = null
            try {
                toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            } catch (e: Exception) {
                // Fallback tone generator
            }

            val pattern = longArrayOf(0, 400, 150, 400, 150)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }

            try {
                while (isActive) {
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 400)
                    delay(450)
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 400)
                    delay(450)
                }
            } finally {
                toneGenerator?.release()
                vibrator?.cancel()
            }
        }
    }

    fun stopSiren() {
        sirenJob?.cancel()
        sirenJob = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        SecurityRepository.setSirenActive(false)
    }
}
