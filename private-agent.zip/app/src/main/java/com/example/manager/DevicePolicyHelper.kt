package com.example.manager

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.receiver.AgentDeviceAdminReceiver

class DevicePolicyHelper(private val context: Context) {

    val devicePolicyManager: DevicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    val adminComponent: ComponentName =
        ComponentName(context, AgentDeviceAdminReceiver::class.java)

    fun isAdminActive(): Boolean {
        return try {
            devicePolicyManager.isAdminActive(adminComponent)
        } catch (e: Exception) {
            false
        }
    }

    fun getAdminActivationIntent(): Intent {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Private Agent requires device administrator authority to enforce remote lock, anti-theft security policies, and device protection."
        )
        return intent
    }

    fun lockNow(): Boolean {
        return try {
            if (isAdminActive()) {
                devicePolicyManager.lockNow()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun isCameraDisabled(): Boolean {
        return try {
            if (isAdminActive()) {
                devicePolicyManager.getCameraDisabled(adminComponent)
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun setCameraDisabled(disabled: Boolean): Boolean {
        return try {
            if (isAdminActive()) {
                devicePolicyManager.setCameraDisabled(adminComponent, disabled)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun setMaximumFailedPasswordsForWipe(num: Int): Boolean {
        return try {
            if (isAdminActive()) {
                devicePolicyManager.setMaximumFailedPasswordsForWipe(adminComponent, num)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun wipeDevice(): Boolean {
        return try {
            if (isAdminActive()) {
                // Safety: wipe data only if explicitly called
                devicePolicyManager.wipeData(0)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun isDeviceSecure(): Boolean {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? android.app.KeyguardManager
        return keyguardManager?.isDeviceSecure ?: false
    }

    fun getCurrentFailedPasswordAttempts(): Int {
        return try {
            if (isAdminActive()) {
                devicePolicyManager.currentFailedPasswordAttempts
            } else {
                0
            }
        } catch (e: Exception) {
            0
        }
    }
}
