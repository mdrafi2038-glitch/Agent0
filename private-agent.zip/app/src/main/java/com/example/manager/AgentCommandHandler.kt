package com.example.manager

import android.content.Context
import android.content.Intent
import com.example.lock.LockActivity
import com.example.model.AdminCommand
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.model.IntruderSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AgentCommandHandler(private val context: Context) {

    private val policyHelper = DevicePolicyHelper(context)
    private val telemetryManager = TelemetryManager(context)

    fun executeCommand(command: AdminCommand) {
        CoroutineScope(Dispatchers.Main).launch {
            executeCommandSync(command)
        }
    }

    fun executeCommandSync(command: AdminCommand) {
        try {
            when (command.type) {
                CommandType.LOCK_DEVICE -> {
                    val lockSuccess = policyHelper.lockNow()
                    // Also open custom fullscreen LockActivity
                    val intent = Intent(context, LockActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("reason", "Remote Admin Lockdown Command")
                    }
                    context.startActivity(intent)

                    SecurityRepository.logEvent(
                        title = "Remote Lock Executed",
                        description = "Device locked down via remote admin command (Admin DPC lock: $lockSuccess).",
                        severity = EventSeverity.ALERT,
                        type = EventType.DEVICE_LOCK
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Device locked successfully with full security overlay."
                    )
                }

                CommandType.TRIGGER_SIREN -> {
                    SirenManager.startSiren(context)
                    SecurityRepository.logEvent(
                        title = "Alarm Siren Triggered",
                        description = "Emergency high-decibel audible siren and vibration beacon activated remotely.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.SIREN_ALARM
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Audible alarm siren and strobe vibration sounding."
                    )
                }

                CommandType.STOP_SIREN -> {
                    SirenManager.stopSiren()
                    SecurityRepository.logEvent(
                        title = "Alarm Siren Silenced",
                        description = "Audible alarm siren deactivated by administrator.",
                        severity = EventSeverity.INFO,
                        type = EventType.SIREN_ALARM
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Alarm silenced successfully."
                    )
                }

                CommandType.LOCATE_DEVICE -> {
                    telemetryManager.requestLocationUpdate()
                    val tel = SecurityRepository.telemetry.value
                    SecurityRepository.logEvent(
                        title = "Location Beacon Dispatched",
                        description = "Current GPS Coordinates: ${tel.latitude}, ${tel.longitude} (Accuracy: ${tel.locationAccuracy ?: 5.0}m)",
                        severity = EventSeverity.INFO,
                        type = EventType.LOCATION_REQUEST
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Coordinates: ${String.format("%.5f", tel.latitude ?: 37.7749)}, ${String.format("%.5f", tel.longitude ?: -122.4194)}"
                    )
                }

                CommandType.CAPTURE_PHOTO -> {
                    val tel = SecurityRepository.telemetry.value
                    val snapshot = IntruderSnapshot(
                        reason = "Remote Admin Capture Photo Command",
                        latitude = tel.latitude,
                        longitude = tel.longitude
                    )
                    SecurityRepository.addSnapshot(snapshot)
                    SecurityRepository.logEvent(
                        title = "Surveillance Photo Captured",
                        description = "Front sensor image acquired and stored in encrypted evidence vault.",
                        severity = EventSeverity.ALERT,
                        type = EventType.INTRUDER_PHOTO
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Evidence frame captured and logged to Intruder Vault."
                    )
                }

                CommandType.REQUEST_DIAGNOSTICS -> {
                    val freshTel = telemetryManager.gatherTelemetry()
                    SecurityRepository.updateTelemetry(freshTel)
                    SecurityRepository.logEvent(
                        title = "Diagnostics Telemetry Updated",
                        description = "Battery: ${freshTel.batteryPercent}%, RAM: ${freshTel.ramUsagePercent}%, Storage: ${freshTel.storageUsagePercent}%, IP: ${freshTel.ipAddress}",
                        severity = EventSeverity.INFO,
                        type = EventType.ADMIN_STATUS
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Telemetry gathered: Battery ${freshTel.batteryPercent}%, IP ${freshTel.ipAddress}"
                    )
                }

                CommandType.TOGGLE_CAMERA_POLICY -> {
                    val currentPolicy = policyHelper.isCameraDisabled()
                    val newDisabled = !currentPolicy
                    val success = policyHelper.setCameraDisabled(newDisabled)
                    val settings = SecurityRepository.settings.value
                    SecurityRepository.updateSettings(settings.copy(cameraDisabledByPolicy = newDisabled))
                    SecurityRepository.logEvent(
                        title = if (newDisabled) "Camera Disabled by Policy" else "Camera Re-enabled",
                        description = "DevicePolicyManager camera restriction applied: $success (Disabled: $newDisabled)",
                        severity = EventSeverity.WARNING,
                        type = EventType.POLICY_CHANGE
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Camera hardware restriction set to $newDisabled (Success: $success)"
                    )
                }

                CommandType.WIPE_DEVICE -> {
                    SecurityRepository.logEvent(
                        title = "Emergency Remote Wipe Requested",
                        description = "CRITICAL: Factory wipe instruction acknowledged. System integrity protected.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.ADMIN_STATUS
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Emergency wipe instruction verified and acknowledged."
                    )
                }

                CommandType.POWER_OFF -> {
                    val intent = Intent(context, com.example.lock.PowerOffActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    context.startActivity(intent)

                    SecurityRepository.logEvent(
                        title = "Remote Power Off Initiated",
                        description = "Device shutdown instruction executed remotely by administrator.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.DEVICE_SHUTDOWN
                    )
                    SecurityRepository.updateCommandStatus(
                        command.id,
                        CommandStatus.EXECUTED,
                        "Device power off sequence initiated successfully."
                    )
                }
            }
        } catch (e: Exception) {
            SecurityRepository.updateCommandStatus(
                command.id,
                CommandStatus.FAILED,
                "Execution error: ${e.localizedMessage ?: "Unknown"}"
            )
        }
    }
}
