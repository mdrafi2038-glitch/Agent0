package com.example.model

enum class EventSeverity {
    INFO,
    WARNING,
    ALERT,
    CRITICAL
}

enum class EventType {
    ADMIN_STATUS,
    DEVICE_LOCK,
    SIREN_ALARM,
    FAILED_PASSWORD,
    LOCATION_REQUEST,
    INTRUDER_PHOTO,
    CHARGER_DISCONNECTED,
    MOTION_ALERT,
    REMOTE_COMMAND,
    POLICY_CHANGE,
    DEVICE_SHUTDOWN
}

data class SecurityEvent(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val description: String,
    val severity: EventSeverity,
    val type: EventType
)

data class DeviceTelemetry(
    val deviceModel: String = "",
    val manufacturer: String = "",
    val brand: String = "",
    val androidVersion: String = "",
    val apiLevel: Int = 0,
    val securityPatch: String = "",
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val batteryTemperature: Float = 25f,
    val batteryHealth: String = "Good",
    val totalRamMb: Long = 0,
    val availableRamMb: Long = 0,
    val ramUsagePercent: Int = 0,
    val totalStorageGb: Float = 0f,
    val availableStorageGb: Float = 0f,
    val storageUsagePercent: Int = 0,
    val ipAddress: String = "127.0.0.1",
    val wifiSsid: String = "Unknown",
    val networkType: String = "Wi-Fi",
    val isConnected: Boolean = true,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationAccuracy: Float? = null,
    val locationAddress: String? = null,
    val isDeviceAdminActive: Boolean = false,
    val isDeviceSecure: Boolean = true,
    val isEncrypted: Boolean = true,
    val isRooted: Boolean = false,
    val isCameraDisabled: Boolean = false,
    val uptimeHours: Long = 0
)

enum class CommandType {
    LOCK_DEVICE,
    TRIGGER_SIREN,
    STOP_SIREN,
    LOCATE_DEVICE,
    CAPTURE_PHOTO,
    REQUEST_DIAGNOSTICS,
    TOGGLE_CAMERA_POLICY,
    WIPE_DEVICE,
    POWER_OFF
}

enum class CommandStatus {
    PENDING,
    EXECUTED,
    FAILED
}

data class AdminCommand(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: CommandType,
    val targetDeviceId: String = "local_device",
    val issuedAt: Long = System.currentTimeMillis(),
    var status: CommandStatus = CommandStatus.PENDING,
    var resultSummary: String = ""
)

data class IntruderSnapshot(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val reason: String,
    val photoUri: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)

data class AgentSettings(
    val antiTheftArmed: Boolean = true,
    val unplugAlarmEnabled: Boolean = true,
    val motionAlarmEnabled: Boolean = false,
    val intruderSelfieEnabled: Boolean = true,
    val maxFailedAttempts: Int = 3,
    val customLockMessage: String = "This device is protected by Private Agent. Please return to the owner.",
    val ownerContactPhone: String = "+1 800-555-0199",
    val emergencyPin: String = "1234",
    val cameraDisabledByPolicy: Boolean = false
)

data class ManagedDevice(
    val deviceId: String,
    val deviceName: String,
    val model: String,
    val osVersion: String,
    val batteryPercent: Int,
    val isOnline: Boolean,
    val isProtected: Boolean,
    val lastSeenTimestamp: Long,
    val latitude: Double? = null,
    val longitude: Double? = null
)
