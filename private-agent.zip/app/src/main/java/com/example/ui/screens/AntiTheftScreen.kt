package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lock.LockActivity
import com.example.manager.SecurityRepository
import com.example.model.AgentSettings
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariantDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary

@Composable
fun AntiTheftScreen() {
    val context = LocalContext.current
    val settings by SecurityRepository.settings.collectAsState()

    var lockMessage by remember(settings.customLockMessage) { mutableStateOf(settings.customLockMessage) }
    var ownerPhone by remember(settings.ownerContactPhone) { mutableStateOf(settings.ownerContactPhone) }
    var emergencyPin by remember(settings.emergencyPin) { mutableStateOf(settings.emergencyPin) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyDark)
            .testTag("anti_theft_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "THEFT PREVENTION & INTRUDER DEFENSE",
                    color = CyberCyanPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Anti-Theft Shield",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Configure sensor triggers, tamper siren, intruder capture, and lock screen security.",
                    color = CyberTextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Sensor Triggers
        item {
            Text(
                text = "SENSOR DEFENSE TRIGGERS",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(1.dp, CyberBorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Master Shield Toggle
                    AntiTheftToggleRow(
                        title = "Master Anti-Theft Shield",
                        desc = "Arm background sensor & intrusion surveillance",
                        icon = Icons.Default.Shield,
                        isChecked = settings.antiTheftArmed,
                        onCheckedChange = { checked ->
                            SecurityRepository.updateSettings(settings.copy(antiTheftArmed = checked))
                        }
                    )

                    // Charger Unplug
                    AntiTheftToggleRow(
                        title = "Charger Disconnect Alarm",
                        desc = "Sound emergency siren if charger is unplugged",
                        icon = Icons.Default.PowerOff,
                        isChecked = settings.unplugAlarmEnabled,
                        onCheckedChange = { checked ->
                            SecurityRepository.updateSettings(settings.copy(unplugAlarmEnabled = checked))
                        }
                    )

                    // Motion Displacement
                    AntiTheftToggleRow(
                        title = "Motion Displacement Alarm",
                        desc = "Detect sudden device movement / pocket snatching",
                        icon = Icons.Default.MotionPhotosOn,
                        isChecked = settings.motionAlarmEnabled,
                        onCheckedChange = { checked ->
                            SecurityRepository.updateSettings(settings.copy(motionAlarmEnabled = checked))
                        }
                    )

                    // Intruder Selfie
                    AntiTheftToggleRow(
                        title = "Intruder Capture on Failed PIN",
                        desc = "Log snapshot and location on incorrect unlock attempts",
                        icon = Icons.Default.CameraAlt,
                        isChecked = settings.intruderSelfieEnabled,
                        onCheckedChange = { checked ->
                            SecurityRepository.updateSettings(settings.copy(intruderSelfieEnabled = checked))
                        }
                    )
                }
            }
        }

        // Lockscreen Customization
        item {
            Text(
                text = "LOCKSCREEN BANNER & CONTACT",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(1.dp, CyberBorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = lockMessage,
                        onValueChange = { lockMessage = it },
                        label = { Text("Custom Lock Message", color = CyberTextSecondary) },
                        modifier = Modifier.fillMaxWidth().testTag("input_lock_message"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyanPrimary,
                            unfocusedBorderColor = CyberBorderDark,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = ownerPhone,
                        onValueChange = { ownerPhone = it },
                        label = { Text("Owner Emergency Phone", color = CyberTextSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("input_owner_phone"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyanPrimary,
                            unfocusedBorderColor = CyberBorderDark,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = emergencyPin,
                        onValueChange = { if (it.length <= 4) emergencyPin = it },
                        label = { Text("4-Digit Emergency PIN (Current: $emergencyPin)", color = CyberTextSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth().testTag("input_emergency_pin"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyanPrimary,
                            unfocusedBorderColor = CyberBorderDark,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (emergencyPin.length != 4) {
                                    Toast.makeText(context, "PIN must be exactly 4 digits", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                SecurityRepository.updateSettings(
                                    settings.copy(
                                        customLockMessage = lockMessage,
                                        ownerContactPhone = ownerPhone,
                                        emergencyPin = emergencyPin
                                    )
                                )
                                Toast.makeText(context, "Settings Saved", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f).testTag("save_settings_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = Color(0xFF00363D), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Config", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                val intent = Intent(context, LockActivity::class.java).apply {
                                    putExtra("reason", "Anti-Theft Preview Mode")
                                }
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f).testTag("preview_lock_btn"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyberCyanPrimary)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Preview Lock", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AntiTheftToggleRow(
    title: String,
    desc: String,
    icon: ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isChecked) CyberCyanPrimary else CyberTextMuted,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(text = desc, color = CyberTextSecondary, fontSize = 11.sp)
            }
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberCyanPrimary,
                checkedTrackColor = Color(0xFF004D56),
                uncheckedThumbColor = CyberTextMuted,
                uncheckedTrackColor = CyberSurfaceVariantDark
            )
        )
    }
}
