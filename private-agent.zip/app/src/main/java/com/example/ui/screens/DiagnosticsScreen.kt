package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.manager.TelemetryManager
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariantDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarningAmber

@Composable
fun DiagnosticsScreen() {
    val context = LocalContext.current
    val telemetry by SecurityRepository.telemetry.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyDark)
            .testTag("diagnostics_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HARDWARE & SECURITY SUITE",
                        color = CyberCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Device Diagnostics",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Button(
                    onClick = {
                        val tel = TelemetryManager(context).gatherTelemetry()
                        SecurityRepository.updateTelemetry(tel)
                        Toast.makeText(context, "Diagnostics Refreshed", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, CyberCyanPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Re-scan", color = CyberCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Security Posture Compliance Audit
        item {
            Text(
                text = "SECURITY INTEGRITY & POLICY AUDIT",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(1.dp, CyberBorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    AuditItemRow(
                        title = "Device Administrator Privileges",
                        desc = if (telemetry.isDeviceAdminActive) "Active (Full DPC access)" else "Inactive (Requires activation)",
                        isPassed = telemetry.isDeviceAdminActive
                    )
                    AuditItemRow(
                        title = "Lockscreen Credential (PIN/Biometric)",
                        desc = if (telemetry.isDeviceSecure) "Secured (Hardware keyguard active)" else "No lockscreen configured",
                        isPassed = telemetry.isDeviceSecure
                    )
                    AuditItemRow(
                        title = "Hardware Storage Encryption",
                        desc = "FBE (File-Based Encryption) active",
                        isPassed = telemetry.isEncrypted
                    )
                    AuditItemRow(
                        title = "Root Integrity / Tamper Check",
                        desc = if (telemetry.isRooted) "POTENTIAL TAMPER (Root binaries detected)" else "Passed (No su / test-keys found)",
                        isPassed = !telemetry.isRooted
                    )
                    AuditItemRow(
                        title = "Hardware Camera Policy",
                        desc = if (telemetry.isCameraDisabled) "Disabled via Admin Policy" else "Enabled (Standard operation)",
                        isPassed = true
                    )
                }
            }
        }

        // Memory & CPU Gauge
        item {
            Text(
                text = "MEMORY & STORAGE",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(1.dp, CyberBorderDark)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // RAM
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RAM Memory (${telemetry.ramUsagePercent}% Used)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("${telemetry.totalRamMb - telemetry.availableRamMb} / ${telemetry.totalRamMb} MB", color = CyberCyanPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { telemetry.ramUsagePercent / 100f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = CyberCyanPrimary,
                            trackColor = CyberSurfaceVariantDark
                        )
                    }

                    // Storage
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Internal Storage (${telemetry.storageUsagePercent}% Used)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("${String.format("%.1f", telemetry.totalStorageGb - telemetry.availableStorageGb)} / ${telemetry.totalStorageGb} GB", color = CyberShieldSecondary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { telemetry.storageUsagePercent / 100f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = CyberShieldSecondary,
                            trackColor = CyberSurfaceVariantDark
                        )
                    }
                }
            }
        }

        // Battery Subsystem
        item {
            Text(
                text = "POWER & BATTERY HEALTH",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(1.dp, CyberBorderDark)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    DiagStatCol(label = "Charge Level", value = "${telemetry.batteryPercent}%", accent = CyberSuccessGreen)
                    DiagStatCol(label = "Status", value = if (telemetry.isCharging) "Charging" else "Discharging", accent = CyberCyanPrimary)
                    DiagStatCol(label = "Temperature", value = "${telemetry.batteryTemperature}°C", accent = CyberShieldSecondary)
                    DiagStatCol(label = "Health", value = telemetry.batteryHealth, accent = CyberSuccessGreen)
                }
            }
        }

        // Hardware Test Suite
        item {
            Text(
                text = "INTERACTIVE HARDWARE TESTS",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Test Vibration
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                v?.vibrate(android.os.VibrationEffect.createOneShot(300, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                            } else {
                                @Suppress("DEPRECATION")
                                v?.vibrate(300)
                            }
                            Toast.makeText(context, "Haptic Vibration Triggered", Toast.LENGTH_SHORT).show()
                        },
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, CyberBorderDark)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.Vibration, contentDescription = null, tint = CyberCyanPrimary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Test Haptics", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Pulse vibration motor", color = CyberTextSecondary, fontSize = 10.sp)
                    }
                }

                // Test Siren Audio Tone
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            SirenManager.startSiren(context)
                            Toast.makeText(context, "Playing Siren Pulse (Auto-stop in 3s)", Toast.LENGTH_SHORT).show()
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                SirenManager.stopSiren()
                            }, 3000)
                        },
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, CyberBorderDark)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = CyberAlertCrimson)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Test Siren", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Audible 3s alarm tone", color = CyberTextSecondary, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditItemRow(title: String, desc: String, isPassed: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = desc, color = CyberTextSecondary, fontSize = 11.sp)
        }
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(
                    if (isPassed) CyberSuccessGreen.copy(alpha = 0.2f) else CyberAlertCrimson.copy(alpha = 0.2f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPassed) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null,
                tint = if (isPassed) CyberSuccessGreen else CyberAlertCrimson,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun DiagStatCol(label: String, value: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CyberTextSecondary, fontSize = 11.sp)
    }
}
