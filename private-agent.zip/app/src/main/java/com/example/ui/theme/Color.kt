package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cybersecurity Cyber Dark Theme
val CyberNavyDark = Color(0xFF0A0F1D)
val CyberSurfaceDark = Color(0xFF111827)
val CyberSurfaceVariantDark = Color(0xFF1E293B)
val CyberBorderDark = Color(0xFF334155)

val CyberCyanPrimary = Color(0xFF00E5FF)
val CyberCyanOnPrimary = Color(0xFF00363D)
val CyberCyanContainer = Color(0xFF004D56)

val CyberShieldSecondary = Color(0xFF38BDF8)
val CyberShieldContainer = Color(0xFF0C4A6E)

val CyberSuccessGreen = Color(0xFF10B981)
val CyberWarningAmber = Color(0xFFF59E0B)
val CyberAlertCrimson = Color(0xFFEF4444)
val CyberPurple = Color(0xFFA855F7)

val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)

// Light Theme Alternates
val CyberNavyLight = Color(0xFF0F172A)
val CyberSurfaceLight = Color(0xFFF8FAFC)
val CyberSurfaceVariantLight = Color(0xFFE2E8F0)
val CyberPrimaryLight = Color(0xFF0284C7)
