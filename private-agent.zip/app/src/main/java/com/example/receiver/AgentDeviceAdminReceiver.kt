package com.example.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.lock.LockActivity
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.model.IntruderSnapshot

class AgentDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        SecurityRepository.logEvent(
            title = "Device Admin Activated",
            description = "Private Agent has been granted Device Administrator privileges. Security policies active.",
            severity = EventSeverity.INFO,
            type = EventType.ADMIN_STATUS
        )
        Toast.makeText(context, "Private Agent Administrator Activated", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        SecurityRepository.logEvent(
            title = "Device Admin Revoked",
            description = "Device Administrator privileges were removed. Anti-theft enforcement may be degraded.",
            severity = EventSeverity.ALERT,
            type = EventType.ADMIN_STATUS
        )
        Toast.makeText(context, "Private Agent Administrator Revoked", Toast.LENGTH_SHORT).show()
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        val settings = SecurityRepository.settings.value
        SecurityRepository.logEvent(
            title = "Failed Passcode Attempt",
            description = "An incorrect unlock attempt was detected on the device lockscreen.",
            severity = EventSeverity.WARNING,
            type = EventType.FAILED_PASSWORD
        )

        // If anti-theft is armed, record intruder snapshot event and trigger lockdown if threshold exceeded
        if (settings.antiTheftArmed) {
            SecurityRepository.addSnapshot(
                IntruderSnapshot(
                    reason = "Failed Lockscreen PIN Attempt",
                    latitude = SecurityRepository.telemetry.value.latitude,
                    longitude = SecurityRepository.telemetry.value.longitude
                )
            )

            // Trigger alarm if repeated intruder attempts
            if (settings.intruderSelfieEnabled) {
                SecurityRepository.logEvent(
                    title = "Intruder Alert Triggered",
                    description = "Repeated incorrect passcode attempts recorded. Lockdown engaged.",
                    severity = EventSeverity.CRITICAL,
                    type = EventType.DEVICE_LOCK
                )

                // Launch LockActivity overlay
                val lockIntent = Intent(context, LockActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("reason", "Intruder Alert - Multiple Failed Attempts")
                }
                context.startActivity(lockIntent)
            }
        }
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        SecurityRepository.logEvent(
            title = "Passcode Succeeded",
            description = "Device unlocked successfully with authorized credentials.",
            severity = EventSeverity.INFO,
            type = EventType.FAILED_PASSWORD
        )
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        super.onPasswordChanged(context, intent)
        SecurityRepository.logEvent(
            title = "Passcode Changed",
            description = "Device security credentials were modified or updated.",
            severity = EventSeverity.INFO,
            type = EventType.POLICY_CHANGE
        )
    }
}
