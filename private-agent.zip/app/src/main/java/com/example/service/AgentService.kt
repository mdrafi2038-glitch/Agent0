package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.manager.TelemetryManager
import com.example.model.EventSeverity
import com.example.model.EventType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AgentService : Service(), SensorEventListener {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    private lateinit var telemetryManager: TelemetryManager
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    private var lastAcceleration = 0f
    private var currentAcceleration = SensorManager.GRAVITY_EARTH
    private var shakeThreshold = 14f

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_POWER_DISCONNECTED) {
                val settings = SecurityRepository.settings.value
                if (settings.antiTheftArmed && settings.unplugAlarmEnabled) {
                    SecurityRepository.logEvent(
                        title = "Charger Disconnected!",
                        description = "Unauthorized power detachment detected while anti-theft shield is armed.",
                        severity = EventSeverity.ALERT,
                        type = EventType.CHARGER_DISCONNECTED
                    )
                    context?.let { SirenManager.startSiren(it) }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        telemetryManager = TelemetryManager(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val filter = IntentFilter(Intent.ACTION_POWER_DISCONNECTED)
        registerReceiver(powerReceiver, filter)

        // Telemetry background polling
        serviceScope.launch {
            while (isActive) {
                val tel = telemetryManager.gatherTelemetry()
                SecurityRepository.updateTelemetry(tel)
                delay(15000)
            }
        }

        registerMotionSensor()
    }

    private fun registerMotionSensor() {
        val settings = SecurityRepository.settings.value
        if (settings.motionAlarmEnabled && accelerometer != null) {
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        lastAcceleration = currentAcceleration
        currentAcceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        val delta = currentAcceleration - lastAcceleration

        val settings = SecurityRepository.settings.value
        if (settings.antiTheftArmed && settings.motionAlarmEnabled && delta > shakeThreshold) {
            SecurityRepository.logEvent(
                title = "Motion Tamper Alert",
                description = "Sudden movement/displacement detected. Theft prevention triggered.",
                severity = EventSeverity.ALERT,
                type = EventType.MOTION_ALERT
            )
            SirenManager.startSiren(this)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        unregisterReceiver(powerReceiver)
        sensorManager?.unregisterListener(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Private Agent Security Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground security monitoring and device anti-theft services"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Private Agent Active")
            .setContentText("Device protected with real-time anti-theft shield")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "private_agent_service_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
