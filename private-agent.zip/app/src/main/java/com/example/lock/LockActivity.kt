package com.example.lock

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.MyApplicationTheme

class LockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val lockReason = intent.getStringExtra("reason") ?: "Administrative Lockdown Engaged"
        SecurityRepository.setLocked(true)

        setContent {
            MyApplicationTheme(darkTheme = true) {
                LockScreen(
                    reason = lockReason,
                    onCallOwner = { phone ->
                        try {
                            val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                            startActivity(callIntent)
                        } catch (e: Exception) {
                            Toast.makeText(this, "Cannot initiate call", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onUnlockSuccess = {
                        SirenManager.stopSiren()
                        SecurityRepository.setLocked(false)
                        SecurityRepository.logEvent(
                            title = "Lockscreen Dismissed",
                            description = "Authorized emergency PIN entered. Device unlocked.",
                            severity = EventSeverity.INFO,
                            type = EventType.DEVICE_LOCK
                        )
                        Toast.makeText(this, "Device Unlocked", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        SecurityRepository.setLocked(false)
    }
}

@Composable
fun LockScreen(
    reason: String,
    onCallOwner: (String) -> Unit,
    onUnlockSuccess: () -> Unit
) {
    val context = LocalContext.current
    val settings by SecurityRepository.settings.collectAsState()
    val isSirenActive by SecurityRepository.isSirenActive.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var failedTries by remember { mutableStateOf(0) }

    // Intercept back button to prevent trivial bypass
    BackHandler {
        pinError = "Device is locked. Enter emergency PIN to exit."
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lock_scale"
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("lock_screen_root"),
        containerColor = CyberNavyDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Glowing Lock Icon
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .scale(if (isSirenActive) scale else 1f)
                    .background(
                        color = if (isSirenActive) CyberAlertCrimson.copy(alpha = 0.2f) else CyberSurfaceDark,
                        shape = CircleShape
                    )
                    .border(
                        width = 2.dp,
                        color = if (isSirenActive) CyberAlertCrimson else CyberCyanPrimary,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Device Locked",
                    tint = if (isSirenActive) CyberAlertCrimson else CyberCyanPrimary,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "PRIVATE AGENT LOCKDOWN",
                color = CyberAlertCrimson,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = reason,
                color = CyberTextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Admin message Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = CyberCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SECURITY NOTICE",
                            color = CyberCyanPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = settings.customLockMessage,
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onCallOwner(settings.ownerContactPhone) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("call_owner_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Call Owner: ${settings.ownerContactPhone}", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (isSirenActive) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { SirenManager.stopSiren() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("silence_siren_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberAlertCrimson),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberAlertCrimson),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.NotificationsOff, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Silence Alarm Siren", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PIN Display
            Text(
                text = "ENTER EMERGENCY PIN TO UNLOCK",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // PIN dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val filled = i < enteredPin.length
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .background(
                                color = if (filled) CyberCyanPrimary else Color.Transparent,
                                shape = CircleShape
                            )
                            .border(
                                width = 2.dp,
                                color = if (filled) CyberCyanPrimary else CyberTextMuted,
                                shape = CircleShape
                            )
                    )
                }
            }

            if (pinError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = pinError ?: "",
                    color = CyberAlertCrimson,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Numeric Keypad
            val keypad = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("CLR", "0", "DEL")
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                for (row in keypad) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        for (key in row) {
                            Surface(
                                modifier = Modifier
                                    .size(64.dp)
                                    .testTag("key_$key")
                                    .clickable {
                                        pinError = null
                                        when (key) {
                                            "CLR" -> enteredPin = ""
                                            "DEL" -> {
                                                if (enteredPin.isNotEmpty()) {
                                                    enteredPin = enteredPin.dropLast(1)
                                                }
                                            }
                                            else -> {
                                                if (enteredPin.length < 4) {
                                                    enteredPin += key
                                                    if (enteredPin.length == 4) {
                                                        if (enteredPin == settings.emergencyPin) {
                                                            onUnlockSuccess()
                                                        } else {
                                                            failedTries++
                                                            pinError = "Incorrect PIN ($failedTries failed)"
                                                            enteredPin = ""
                                                            if (failedTries >= settings.maxFailedAttempts) {
                                                                SirenManager.startSiren(context)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    },
                                shape = CircleShape,
                                color = CyberSurfaceDark,
                                tonalElevation = 4.dp,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (key == "DEL") {
                                        Icon(
                                            imageVector = Icons.Default.Backspace,
                                            contentDescription = "Backspace",
                                            tint = CyberTextSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    } else {
                                        Text(
                                            text = key,
                                            color = Color.White,
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Default Admin Emergency PIN: ${settings.emergencyPin}",
                color = CyberTextMuted,
                fontSize = 11.sp
            )
        }
    }
}
