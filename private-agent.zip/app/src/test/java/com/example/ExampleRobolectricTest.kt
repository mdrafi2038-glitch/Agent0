package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.manager.AgentCommandHandler
import com.example.manager.SecurityRepository
import com.example.model.AdminCommand
import com.example.model.AgentSettings
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.EventSeverity
import com.example.model.EventType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  private lateinit var context: Context

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext<Context>()
    SecurityRepository.initialize(context)
  }

  @Test
  fun `read app name string from context`() {
    val appName = context.getString(R.string.app_name)
    assertEquals("Private Agent", appName)
  }

  @Test
  fun `read client and admin app names from context`() {
    val clientName = context.getString(R.string.client_app_name)
    val adminName = context.getString(R.string.admin_app_name)
    assertEquals("Private Agent (Client)", clientName)
    assertEquals("Private Agent (Admin)", adminName)
  }

  @Test
  fun `admin main activity can be created`() {
    val controller = org.robolectric.Robolectric.buildActivity(com.example.admin.AdminMainActivity::class.java)
    val activity = controller.create().start().resume().get()
    assertNotNull(activity)
  }

  @Test
  fun `security repository logs event correctly`() {
    SecurityRepository.logEvent(
      title = "Test Incident",
      description = "Test verification of security event stream",
      severity = EventSeverity.ALERT,
      type = EventType.ADMIN_STATUS
    )

    val events = SecurityRepository.events.value
    assertTrue(events.isNotEmpty())
    val latest = events.first()
    assertEquals("Test Incident", latest.title)
    assertEquals(EventSeverity.ALERT, latest.severity)
  }

  @Test
  fun `security settings update and persist`() {
    val newSettings = AgentSettings(
      antiTheftArmed = true,
      unplugAlarmEnabled = true,
      motionAlarmEnabled = true,
      intruderSelfieEnabled = true,
      customLockMessage = "Custom Protected Device",
      ownerContactPhone = "+1 555-0199",
      emergencyPin = "9876"
    )

    SecurityRepository.updateSettings(newSettings)
    val current = SecurityRepository.settings.value
    assertEquals("Custom Protected Device", current.customLockMessage)
    assertEquals("9876", current.emergencyPin)
  }

  @Test
  fun `command handler executes diagnostics command`() {
    val handler = AgentCommandHandler(context)
    val cmd = AdminCommand(type = CommandType.REQUEST_DIAGNOSTICS)
    SecurityRepository.addCommand(cmd)
    handler.executeCommandSync(cmd)

    val commands = SecurityRepository.commands.value
    assertTrue(commands.isNotEmpty())
  }

  @Test
  fun `command handler executes simulated remote lock command`() {
    val handler = AgentCommandHandler(context)
    val cmd = AdminCommand(type = CommandType.LOCK_DEVICE)
    SecurityRepository.addCommand(cmd)
    handler.executeCommandSync(cmd)

    val events = SecurityRepository.events.value
    assertTrue(events.any { it.title.contains("Remote Lock") || it.type == EventType.DEVICE_LOCK })
  }

  @Test
  fun `command handler executes simulated wipe data command`() {
    val handler = AgentCommandHandler(context)
    val cmd = AdminCommand(type = CommandType.WIPE_DEVICE)
    SecurityRepository.addCommand(cmd)
    handler.executeCommandSync(cmd)

    val events = SecurityRepository.events.value
    assertTrue(events.any { it.title.contains("Wipe") })
  }

  @Test
  fun `command handler executes simulated locate device command`() {
    val handler = AgentCommandHandler(context)
    val cmd = AdminCommand(type = CommandType.LOCATE_DEVICE)
    SecurityRepository.addCommand(cmd)
    handler.executeCommandSync(cmd)

    val events = SecurityRepository.events.value
    assertTrue(events.any { it.type == EventType.LOCATION_REQUEST })
  }

  @Test
  fun `command handler executes simulated power off command`() {
    val handler = AgentCommandHandler(context)
    val cmd = AdminCommand(type = CommandType.POWER_OFF)
    SecurityRepository.addCommand(cmd)
    handler.executeCommandSync(cmd)

    val events = SecurityRepository.events.value
    assertTrue(events.any { it.type == EventType.DEVICE_SHUTDOWN })
    val commands = SecurityRepository.commands.value
    assertTrue(commands.any { it.type == CommandType.POWER_OFF && it.status == CommandStatus.EXECUTED })
  }
}
